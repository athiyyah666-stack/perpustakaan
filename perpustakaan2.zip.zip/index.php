<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplikasi Perpustakaan Sekolah Digital</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="vh-100 row justify-content-center align-content-center">
    <div class="col-md-2">
        <div class="card p-3 text-center">
            <h1>Selamat Datang</h1>
            <h5>Halaman Login Admin</h5>
            <a href="login-admin.php" class="btn btn-success w-100 mb-2">Login Admin</a>
        </div>
    </div>
    <div class="col-md-2">
        <div class="card p-3 text-center">
            <h1>Selamat Datang</h1>
            <h5>Halaman Login Anggota</h5>
            <a href="login-anggota.php" class="btn btn-success w-100 mb-2">Login Anggota</a>
        </div>
    </div>
    <div class="col-md-2">
        <div class="card p-3 text-center">
            <h1>Selamat Datang</h1>
            <h5>Halaman Pendaftaran Anggota</h5>
            <a href="pendaftaran-anggota.php" class="btn btn-primary w-100 mb-2">Pendaftaran Anggota</a>
        </div>
    </div>
</div>
</body>
</html>